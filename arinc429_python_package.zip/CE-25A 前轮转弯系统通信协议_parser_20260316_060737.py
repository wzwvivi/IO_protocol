# -*- coding: utf-8 -*-
"""
CE-25A 前轮转弯系统通信协议 - ARINC429 解析脚本
版本: V5.0
基于 CE-25A项目0号机前轮转弯系统通信协议EOICD-V5.0 文档

自动生成时间: 2026-03-16 06:07:37
"""

import sys
import os
from datetime import datetime

# 导入 ARINC429 运行时模块
# 确保 arinc429_runtime.py 在同一目录或 Python 路径中
try:
    from arinc429_runtime import (
        reverse_bits_8, extract_label, extract_bit, extract_bits,
        check_odd_parity, decode_ssm, decode_bnr_signed, decode_bnr_unsigned,
        interpret_discrete_desc, parse_hex_input, load_raw_byte_file,
        create_excel_workbook, write_excel_row, finalize_excel
    )
except ImportError:
    print("错误: 找不到 arinc429_runtime.py 模块")
    print("请确保该文件与本脚本在同一目录下")
    sys.exit(1)


# ============================================================
# 协议定义 - CE-25A 前轮转弯系统通信协议
# ============================================================


LABEL_444 = {
    'label_oct': '444',
    'label_dec': 0o444,  # = 292
    'name': '自定义',
    'direction': 'RDIU -> SCU',
    'sources': [],
    'data_type': 'DISCRETE',
    'unit': '',
    'range': '',

    'resolution': None,
    'encoding': 'BNR',

    'discrete_bits': {

        12: '脚蹬',

    },


    'special_fields': [

        {'name': '脚蹬', 'bits': (12, 16), 'values': {

            10: '转弯',

        }},

    ],


    'reserved_bits': '9-11，13，27，28',
    'notes': ''
}


# ============================================================
# Label 查找表
# ============================================================

LABEL_LOOKUP = {}
for _def in [LABEL_444]:
    LABEL_LOOKUP[_def['label_dec']] = _def


# ============================================================
# 核心解析函数
# ============================================================

def parse_arinc429_word(word):
    """完整解析一个32位ARINC429数据字
    
    Args:
        word: 32位整数 (bit1在最低位)
    Returns:
        dict: 解析结果
    """
    result = {}
    
    # 1. 原始数据
    result['raw_hex'] = f'0x{word:08X}'
    result['raw_bin'] = f'{word:032b}'[::-1]  # bit1在左
    
    # 2. 提取Label
    label_dec, label_oct = extract_label(word)
    result['label_dec'] = label_dec
    result['label_oct'] = label_oct
    
    # 3. 提取SDI (bits 9-10)
    sdi = extract_bits(word, 9, 10)
    result['sdi'] = sdi
    
    # 4. 提取SSM (bits 30-31)
    ssm = extract_bits(word, 30, 31)
    result['ssm_raw'] = ssm
    result['ssm_desc'] = decode_ssm(ssm)
    
    # 5. 提取奇校验位 (bit 32)
    parity_bit = extract_bit(word, 32)
    result['parity_bit'] = parity_bit
    result['parity_ok'] = check_odd_parity(word)
    
    # 6. 查找协议定义
    word_def = LABEL_LOOKUP.get(label_dec)
    if word_def:
        result['known'] = True
        result['name'] = word_def['name']
        result['direction'] = word_def['direction']
        result['sources'] = word_def['sources']
        result['unit'] = word_def.get('unit', '')
        result['range'] = word_def.get('range', '')
        result['notes'] = word_def.get('notes', '')
        
        # 7. 根据数据类型解码
        dtype = word_def['data_type']
        
        if dtype == 'BNR_SIGNED':
            ds, de = word_def['data_bits']
            sb = word_def['sign_bit']
            res = word_def['resolution']
            data_raw, sign, phys_val = decode_bnr_signed(word, ds, de, sb, res)
            result['data_raw'] = data_raw
            result['sign'] = sign
            result['sign_desc'] = '正' if sign == 0 else '负'
            result['physical_value'] = phys_val
            result['physical_str'] = f'{phys_val:.6f} {word_def["unit"]}'
            result['resolution'] = res
            result['data_bits_range'] = f'bit{ds}-bit{de} ({de-ds+1}位)'
            
        elif dtype == 'BNR_UNSIGNED':
            ds, de = word_def['data_bits']
            res = word_def['resolution']
            data_raw, phys_val = decode_bnr_unsigned(word, ds, de, res)
            result['data_raw'] = data_raw
            result['sign'] = None
            result['physical_value'] = phys_val
            result['physical_str'] = f'{phys_val:.4f} {word_def["unit"]}'
            result['resolution'] = res
            result['data_bits_range'] = f'bit{ds}-bit{de} ({de-ds+1}位)'
            
        elif dtype == 'DISCRETE':
            # 解码各离散位
            discrete_results = []
            if 'discrete_bits' in word_def:
                for bit_num, desc in sorted(word_def['discrete_bits'].items()):
                    bit_val = extract_bit(word, bit_num)
                    discrete_results.append({
                        'bit': bit_num,
                        'value': bit_val,
                        'description': desc
                    })
            
            # 解码特殊多位字段
            special_results = []
            if 'special_fields' in word_def:
                for sf in word_def['special_fields']:
                    bs, be = sf['bits']
                    field_val = extract_bits(word, bs, be)
                    if 'values' in sf:
                        val_desc = sf['values'].get(field_val, f'未定义({field_val})')
                        special_results.append({
                            'name': sf['name'],
                            'bits': f'bit{bs}-bit{be}',
                            'raw_value': field_val,
                            'description': val_desc
                        })
                    elif sf.get('type') == 'uint':
                        special_results.append({
                            'name': sf['name'],
                            'bits': f'bit{bs}-bit{be}',
                            'raw_value': field_val,
                            'description': str(field_val)
                        })
            
            result['discrete_bits'] = discrete_results
            result['special_fields'] = special_results
    else:
        result['known'] = False
        result['name'] = f'未知Label ({label_oct} oct)'
        all_bits = {}
        for i in range(1, 33):
            all_bits[i] = extract_bit(word, i)
        result['all_bits'] = all_bits
    
    return result


def format_parse_result(result):
    """将解析结果格式化为可读字符串"""
    lines = []
    lines.append('=' * 60)
    lines.append(f'ARINC429 数据字解析结果')
    lines.append('=' * 60)
    lines.append(f'原始数据 (HEX): {result["raw_hex"]}')
    lines.append(f'原始数据 (BIN): {result["raw_bin"]}')
    lines.append(f'')
    lines.append(f'--- 标签 (Label) ---')
    lines.append(f'  Label (八进制): {result["label_oct"]}')
    lines.append(f'  Label (十进制): {result["label_dec"]}')
    lines.append(f'')
    lines.append(f'--- SDI (Bits 9-10) ---')
    lines.append(f'  SDI: {result["sdi"]:02b} ({result["sdi"]})')
    lines.append(f'')
    lines.append(f'--- 状态矩阵 SSM (Bits 30-31) ---')
    lines.append(f'  SSM: {result["ssm_raw"]:02b} -> {result["ssm_desc"]}')
    lines.append(f'')
    lines.append(f'--- 奇校验 (Bit 32) ---')
    lines.append(f'  校验位: {result["parity_bit"]}')
    lines.append(f'  校验结果: {"通过" if result["parity_ok"] else "失败"}')
    lines.append(f'')
    
    if result['known']:
        lines.append(f'--- 信号识别 ---')
        lines.append(f'  信号名称: {result["name"]}')
        lines.append(f'  方向: {result["direction"]}')
        lines.append(f'  可能来源: {", ".join(result["sources"])}')
        if result.get('range'):
            lines.append(f'  信号范围: {result["range"]}')
        if result.get('notes'):
            lines.append(f'  备注: {result["notes"]}')
        lines.append(f'')
        
        if 'physical_value' in result:
            lines.append(f'--- 数据解析 ---')
            lines.append(f'  数据位范围: {result.get("data_bits_range", "N/A")}')
            lines.append(f'  原始数据值: {result["data_raw"]} (0x{result["data_raw"]:X})')
            if result.get('sign') is not None:
                lines.append(f'  符号位: {result["sign"]} ({result["sign_desc"]})')
            lines.append(f'  分辨率: {result["resolution"]}')
            lines.append(f'  物理值: {result["physical_str"]}')
        
        if 'discrete_bits' in result and result['discrete_bits']:
            lines.append(f'--- 离散位解析 ---')
            for db in result['discrete_bits']:
                field_name, interp = interpret_discrete_desc(db['description'], db['value'])
                lines.append(f'  Bit {db["bit"]}: {db["value"]} -> [{field_name}] {interp}')
        
        if 'special_fields' in result and result['special_fields']:
            lines.append(f'--- 特殊字段解析 ---')
            for sf in result['special_fields']:
                lines.append(f'  {sf["name"]} ({sf["bits"]}): {sf["raw_value"]} -> {sf["description"]}')
    else:
        lines.append(f'--- 未识别的Label ---')
        lines.append(f'  此Label未在协议中定义')
    
    lines.append('=' * 60)
    return '\n'.join(lines)


def parse_batch_to_excel(words, output_path=None):
    """批量解析ARINC429字并输出到Excel"""
    if output_path is None:
        ts = datetime.now().strftime('%Y%m%d_%H%M%S')
        script_dir = os.path.dirname(os.path.abspath(__file__))
        output_path = os.path.join(script_dir, f'ARINC429_解析结果_{ts}.xlsx')
    
    wb, ws, headers = create_excel_workbook()
    
    for idx, word in enumerate(words, 1):
        result = parse_arinc429_word(word)
        write_excel_row(ws, idx + 1, result, word, LABEL_LOOKUP)
    
    finalize_excel(wb, ws, output_path)
    return output_path


def print_all_labels():
    """打印所有已定义的Label列表"""
    print('\n已定义的ARINC429 Label列表:')
    print('-' * 70)
    print(f'{"Label(Oct)":<12} {"名称":<25} {"方向":<15} {"数据类型":<15}')
    print('-' * 70)
    
    sorted_defs = sorted(LABEL_LOOKUP.values(), key=lambda x: x['label_dec'])
    for d in sorted_defs:
        print(f'{d["label_oct"]:<12} {d["name"]:<25} {d["direction"]:<15} {d["data_type"]:<15}')
    print('-' * 70)


def interactive_mode():
    """交互式解析模式"""
    print('=' * 60)
    print('CE-25A 前轮转弯系统通信协议 - ARINC429 解析器')
    print('版本: V5.0')
    print('=' * 60)
    print()
    print('使用方法:')
    print('  输入32位HEX: 67FF00B2 或 0x67FF00B2')
    print('  输入4字节:   B2 00 FF 67 (小端序, Label字节在前)')
    print('  输入 "list" 查看所有已定义的Label')
    print('  输入 "quit" 或 "exit" 退出')
    print('  输入 "file <路径>" 从文件批量解析')
    print('  输入 "raw <路径>"  从原始字节文件解析')
    print()
    
    while True:
        try:
            user_input = input('请输入ARINC429数据字 (hex): ').strip()
        except (EOFError, KeyboardInterrupt):
            print('\n退出.')
            break
        
        if not user_input:
            continue
        
        if user_input.lower() in ('quit', 'exit', 'q'):
            print('退出.')
            break
        
        if user_input.lower() == 'list':
            print_all_labels()
            continue
        
        if user_input.lower().startswith('raw '):
            filepath = user_input[4:].strip()
            if os.path.exists(filepath):
                print(f'正在从原始字节文件读取: {filepath}')
                words = load_raw_byte_file(filepath)
                if words:
                    print(f'读取到 {len(words)} 个数据字, 正在解析...')
                    out = parse_batch_to_excel(words)
                    print(f'结果已保存到: {out}')
                else:
                    print('文件中没有有效数据')
            else:
                print(f'文件不存在: {filepath}')
            continue
        
        if user_input.lower().startswith('file '):
            filepath = user_input[5:].strip()
            if os.path.exists(filepath):
                print(f'正在从文件读取: {filepath}')
                words = []
                with open(filepath, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            try:
                                words.append(parse_hex_input(line))
                            except ValueError:
                                print(f'  跳过无效行: {line}')
                if words:
                    print(f'读取到 {len(words)} 个数据字, 正在解析...')
                    out = parse_batch_to_excel(words)
                    print(f'结果已保存到: {out}')
                else:
                    print('文件中没有有效数据')
            else:
                print(f'文件不存在: {filepath}')
            continue
        
        # 尝试解析hex输入
        try:
            word = parse_hex_input(user_input)
            result = parse_arinc429_word(word)
            print(format_parse_result(result))
        except ValueError as e:
            print(f'输入格式错误: {e}')
            print('请输入有效的32位十六进制数 (如: 67FF00B2 或 B2 00 FF 67)')


if __name__ == '__main__':
    if len(sys.argv) > 1:
        arg = sys.argv[1]
        
        if arg == '--list':
            print_all_labels()
        elif arg == '--raw' and len(sys.argv) > 2:
            filepath = sys.argv[2]
            if os.path.exists(filepath):
                words = load_raw_byte_file(filepath)
                if words:
                    print(f'从原始文件读取到 {len(words)} 个ARINC429数据字')
                    out = parse_batch_to_excel(words)
                    print(f'结果已保存到: {out}')
            else:
                print(f'文件不存在: {filepath}')
        elif arg == '--file' and len(sys.argv) > 2:
            filepath = sys.argv[2]
            if os.path.exists(filepath):
                words = []
                with open(filepath, 'r') as f:
                    for line in f:
                        line = line.strip()
                        if line and not line.startswith('#'):
                            try:
                                words.append(parse_hex_input(line))
                            except ValueError:
                                pass
                if words:
                    out = parse_batch_to_excel(words)
                    print(f'结果已保存到: {out}')
            else:
                print(f'文件不存在: {filepath}')
        elif arg == '--help':
            print('用法:')
            print('  python CE-25A 前轮转弯系统通信协议_parser.py              # 交互模式')
            print('  python CE-25A 前轮转弯系统通信协议_parser.py <hex>         # 解析单个数据字')
            print('  python CE-25A 前轮转弯系统通信协议_parser.py --list        # 列出所有Label')
            print('  python CE-25A 前轮转弯系统通信协议_parser.py --file <f>    # 从文件批量解析')
            print('  python CE-25A 前轮转弯系统通信协议_parser.py --raw <f>     # 从原始字节文件解析')
        else:
            try:
                if len(sys.argv) == 5:
                    combined = ' '.join(sys.argv[1:5])
                    word = parse_hex_input(combined)
                else:
                    word = parse_hex_input(arg)
                result = parse_arinc429_word(word)
                print(format_parse_result(result))
            except ValueError as e:
                print(f'输入格式错误: {e}')
    else:
        interactive_mode()